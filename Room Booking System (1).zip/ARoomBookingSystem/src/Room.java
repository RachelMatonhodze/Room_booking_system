public class Room {
	
	
	//Field of the varaibles.
	String roomNo;
	String roomType;
	double roomPrice;
	boolean roomBalcony;
	boolean roomLounge;
	 String guestEmail;

	

	
    //Constructor for the Room. The constructor is used to define the object.
	public Room(String roomNo, String roomType, double roomPrice, boolean roomBalcony, boolean roomLounge, String guestEmail) {
		this.roomNo = roomNo; //"This." is used to access the variables.
		this.roomType = roomType;
		this.roomPrice = roomPrice;
		this.roomBalcony = roomBalcony;
		this.roomLounge = roomLounge;
		this.guestEmail = guestEmail;
	}
	
	//The toString method displays the room data.
		public String toString() {
			String result = roomNo + " " + roomType + " " + roomPrice  + " " +roomBalcony + " " + roomLounge + " " + guestEmail;
			return result;
		
		}
		
	//Method to get the guest email that returns the guest email.
	public  String getGuestEmail() {
		return guestEmail;
	}
	
	//Method to set the guest email, where guestEmail is a string. This method is void which means it should not return a value.
	public void setGuestEmail(String guestEmail) {
		this.guestEmail = guestEmail;
	}
	
	//Method to get the room number. The room number is returned
	public String getRoomNo() {
		return roomNo;
	}
	
	//Method that is used to get the room type. The room type is returned.
	public String getRoomType() {
		return roomType;
		
	}
	//Method that is used to get the room price. The room price is returned
	public double getRoomPrice() {
		return roomPrice;
	}
	
	//Method is used to check whether a balcony is wanted by the user.
	public boolean hasBalcony() {
		return roomBalcony;
		
	}
	//Method is used to check whether a lounge is wanted by the user.
	public boolean hasLounge() {
		return roomLounge;
		
	}
	
}
