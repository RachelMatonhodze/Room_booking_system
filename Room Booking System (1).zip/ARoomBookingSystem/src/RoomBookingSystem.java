import java.util.ArrayList; //This sets up an array list.
import java.util.Scanner; //Used for user input. 
import java.io.FileNotFoundException; //Used for error handling. The object FileNotFoundException is thrown by the code if the file can't be found.
import java.io.FileReader; //Reads what is in the file.
import java.io.FileWriter; //Used to write text to a file.
import java.io.IOException; //Used for input and output exceptions.
import java.io.PrintWriter; //Used to write formatted data to files.


public class RoomBookingSystem {
	
	private static Room[] roomArray = null; //The array is declared.
	private static Scanner input = new Scanner(System.in); //This declares the object and allows you to read the input. 

	public static void main(String[] args) throws Exception {
		
		loadRooms();
		String choice = " "; //This creates an empty choice menu for the user.
		//This is a do while loop where the block of code is exected once, it then checks if the condition is true,if it's true the loop will be repeated. The code would've been executed once even if the condition was false.
		do { 
			//The text that is going to show when the code runs.
			System.out.println("--Room Booking System--\n");
			System.out.println("-- MAIN MENU --");
			System.out.println("1-Display Bookings ");
			System.out.println("2-Cancel Room ");
			System.out.println("3-View Room Rervations ");
			System.out.println("Q-Quit ");
			System.out.println("Pick: ");
			
			choice = input.next().toUpperCase(); //Gets users input and converts input to uppercase letters.
			
			//A switch case is used here since there are three seperate tasks.
			switch (choice) {
			case "1": {
				displayBookings();
				break; //This terminates the do while loop when user chooses one of the options, then shows the statement to do with the option. 
			}
			case "2": {
				cancelRoom();
				break;
			}
			case "3": {
				reserveRoom();
				break;
			}
		}	
	}
	while (!choice.equalsIgnoreCase("Q")); //Compares the two strings, irregardless of the case, in this instance it is "Q" and "q".
		System.out.println("-- PROGRAMME QUIT --"); //Appears on the console when user enters in "Q" or "q".
		System.exit(0); //Terminates when program is successful.
		
	}
	
	private static void loadRooms() throws FileNotFoundException { //Method which loads content from the text file into appropriate data structures
		Scanner file = new Scanner (new FileReader("rooms.txt")); //reads the file
		
		ArrayList<Room> list = new ArrayList<Room>(); //An array list object, where elements can be added.
		//Scans the text file. E.g, scans the roomPrice as a double.
		while(file.hasNext()) {
		    String roomNo = file.next();
			String roomType = file.next();
			double roomPrice = file.nextDouble();
			boolean roomBalcony = file.nextBoolean();
			boolean roomLounge = file.nextBoolean();
			String guestEmail = file.next();
			
			list.add(new Room(roomNo, roomType, roomPrice, roomBalcony, roomLounge, guestEmail));
		}
		//Creates an array list.
		roomArray = new Room[list.size()];
		list.toArray(roomArray);
		file.close();
		}
	public static void displayBookings() throws FileNotFoundException { //Method that displays all the bookings.
		System.out.print("-- ROOM INFORMATION --\n"); //Appears on the console when user chooses "Display bookings".
		for (int i=0; i<roomArray.length; i++) { //The for loop is used to iterate each element of the roomArray.
			System.out.println(roomArray[i].toString()); //Prints out the array list.
		
		}	
	}
	
	public static void cancelRoom() throws IOException { //Method that cancels a reservation.
		int get = 0;
		Room found = null;
		System.out.println("Please enter your room number: ");//This displays on the console when the user chooses the option "Cancel Room".
		String userResponse = input.next(); //This allows the user to enter the room number they would like to cancel
		for (Room i:roomArray) { //The for loop iterates through each element of the roomArray.
			if(i.getRoomNo().equalsIgnoreCase(userResponse)) { //If the room number that the user has entered is booked, it asks the user if they want to cancel the room.
				found = i;
				break;
			}
		}
			
		if(found==null) { //If the room number the user entered is free, it will print out the following below:
			System.out.println("The room has not been booked yet");
			return;
			}
		
		System.out.println("Cancel the room? "); //This appears on the console when the user has entered a room number that has been booked.
		System.out.println("1. Yes"); 
		System.out.println("2. No");
		
		while(true) {
			get = Integer.parseInt(input.next());
			
			if(get==1) { //An if statement for the options 1 and 2.
				found.setGuestEmail("free"); //If the user enters 1, the guestEmail string (for the room that is being cancelled) changes from the email that was previously entered, back to free.
				update(); //This updates the file
				System.out.println("The room has been cancelled!"); //This appears on the console when the user selects 1.
				break;
			}
			else if (get==2) { //If the user enters 2, the room will not be cancelled.
				System.out.println("The room has not been cancelled");
				break;
			}
			else {
				assert false; //This is a function that checks if the logic returns a false statement (if the user enters anything else either than 1 or 2).
				System.out.println("Please enter either number 1 or 2"); //Appears on the console when user enters anything either than 1 or 2.
			}
		}
		}
	
		public static void reserveRoom() throws IOException { //Method that allows you to book a room.
	
			String choice = " ";
			String room = "";
			boolean roomBalcony = false;
			boolean roomLounge = false;
			
			//Appears on the console when user chooses "View Room Reservations".
			System.out.println("-- RESERVE ROOM --"); 
			System.out.println("What room type would you like? ");
			System.out.println("1. Single");
			System.out.println("2. Double");
			System.out.println("3. Suite");
			
			choice = input.next().toUpperCase(); //Converts users input into an uppercase letter.
			
			//A switch case is used since there is three different options for reserving a room. 
			switch(choice) {
			case "1":
				room = "Single";
				break; //The break jumps out of the switch case once the user enters one of the options.
			
			case "2":
				room = "Double";
				break;
			
			case "3":
				room = "Suite";
				break;
				
						}
		
			//This appears on the console when the user selects one of the room types.
			System.out.println("Would you like to have a balcony?");
			System.out.println("1. I want balcony");
			System.out.println("2. No, thanks");
			
			switch(numberInput(1, 2)) { //Number input ensures user can only select either 1 or 2 or else a message will apear on the console.
			case 1:
				roomBalcony = true;
				break;
				
			case 2:
				roomBalcony = false;
				break;
				
			default:
				assert(false); //
			}
		
			//Appears on the console when the user selects if they want a balcony or not.
			System.out.println("Would you like to have a lounge?");
			System.out.println("1. I want a lounge");
			System.out.println("2. No, thanks");
			
			switch(numberInput(1, 2)) {
			case 1:
				roomLounge = true;
				break;
				
			case 2:
				roomLounge = false;
				break;
				
			default:
				assert(false); //A function that checks if the logic returns a false statement (if the user enters anything else either than 1 or 2). 
			}
		for (Room entry:roomArray) { //Uses a for loop where it goes through the room Array to see if the room desired by the user is available.
			boolean result = true;
			String userInput; 
			
			//Checks the users entry requirements to the list in the array
			result = result&&(entry.getRoomType().equalsIgnoreCase(room));
			result = result&&(entry.hasBalcony()==roomBalcony);
			result = result&&(entry.hasLounge()==roomLounge);
			result = result&&(entry.getGuestEmail().equalsIgnoreCase("free"));
			if(result) { //If there is a match (if the email says "free"), the message below will appear on the console:
				System.out.println("A room has been found for you");
				
				//The room information that matches the users requirement appears on the console.
				System.out.println("-- ROOM INFO --");
				}
				System.out.printf("\nRoom Number : %s%n ", entry.getRoomNo());
				System.out.printf("Room Type : %s%n ", entry.getRoomType());
				System.out.printf("Room Price : �%.2f%n ", entry.getRoomPrice());
				System.out.printf("Room Balcony : %s%n ", entry.hasBalcony());
				System.out.printf("Room Lounge : %s%n ", entry.hasLounge());
				System.out.printf("Room Reserved by : %s%n ", entry.getGuestEmail());
			
				//Asks the user if they want to reserve the room.
				System.out.println("Do you want to reserve this room? Y/N");
				choice = input.next(); //Takes input from the user. 
				if(choice.matches("Y") || choice.matches("y")) { //Allows user to either enter uppercase "Y" or lowercase "y".
					System.out.println("Please enter your E-mail: "); //This displays the console when user enters y.
					String emailInput = input.next(); //Allows user to enter their email.
					if(emailInput.length()==0 || !inputEmail(emailInput)) { //Makes sure user enters a valid email.
						System.out.println("There is an error in your E-mail, Please try again."); //If the users email is invalid, this message displays on the console.
						return;
						}
					else { //If the email is valid, the file is updated and the message below is displayed.
						entry.setGuestEmail(emailInput); 
						update(); 
						System.out.println("Your room has been booked");
					}
				}
				//If the user does not want the room, they can either enter the uppercase or lowercase n, then the message below will appear on the console.
				else if(choice.matches("N") || choice.matches("n")) { 
					System.out.println("We're sorry to hear that...");
				}
		
				return;
		
			}
		
		
		//This appears on the console when the users desired room is already booked.
		System.out.printf("The room you want is unavailable"); 
		}

		private static int numberInput(int min, int max) { //A method that checks if the number a user has entered is valid.
			while (true) {
				try {
					System.out.print(" ");
					int number = Integer.parseUnsignedInt(input.next()); 
					if (number>=min&&number<=max) { //Checks  the number that the user enters to make sure it does not exceed the number of options that are displayed on the console.
						return number;
					}
				}
					catch(Exception ex) {	//The try catch statement tests the code for errors.
					}
					System.out.println("The number you entered is invalid, please try again!"); //The try catch displays this message when the user has entered a wrong number.
			}
		
		}
		private static boolean inputEmail (String emailInput) { //Method that checks if the user enters a valid email address.
			String[] Email =emailInput.split("@"); //Makes sure that the user enters an "@" when entering the email.
			boolean result = Email.length==2&&Email[1].length()!=0&&!(emailInput.contains(" ")); //Ensures the user enters some text after the "@".
			return result; 
		}
		
		private static void update() throws IOException { //A method that updates the file when a room has been booked so the email can replaces "free" and is also used when a booking has been cancelled so it goes back to "free".
			
				FileWriter overwrite = new FileWriter("rooms.txt"); //Overwirites the file with the update.
				for(Room entry:roomArray) { //Goes through the roomArray list and overwrites it.
					overwrite.write(entry.toString()); //Overwrites old data with the new data.
					overwrite.write("\n");
				}
				overwrite.flush(); //Flushes data that was added before.
				overwrite.close(); //Closes the overwrite.
			}
	
		public static void saveToFile() throws IOException { //Method that saves the data back to the file.
			PrintWriter file = new PrintWriter ("rooms.txt"); //Allows you to write to the file.
			for (Room entry : roomArray) {
				
				//If the room is either cancelled or booked, the guestEmail on the file changes. 
				String output = entry.getGuestEmail(); 
				if (entry.guestEmail !=null) 
					output += roomArray;
				
				file.println(output); //Prints the output to the fike.
				file.close(); //Closes the file.
			}
		}
}
	
